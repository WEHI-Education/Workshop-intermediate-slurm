#!/usr/bin/env python3
import csv, sys

try:
    fname = sys.argv[1]
except:
    sys.exit("I need a filename!")

err = 0.
n = 0
with open(fname, "r") as f:
    reader = csv.reader(f, delimiter=' ', skipinitialspace=True)
    for row in reader:
        err += abs(float(row[3]))
        n += 1

print(f"Average Absolute Error: {err/n}")
