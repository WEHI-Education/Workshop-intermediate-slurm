#!/bin/bash
# pi-submit.sh

#SBATCH --job-name=pi-submit
#SBATCH --output=%x-%a.out
#SBATCH --array=0-6
#SBATCH --cpus-per-task=2

# setting SLURM_ARRAY_TASK_ID in case not run in array job
if [ -z SLURM_ARRAY_TASK_ID ]
then
    id=0
else
    id=$SLURM_ARRAY_TASK_ID
fi

# setting SLURM_CPUS_PER_TASK in case not run in Slurm job
if [ -z SLURM_CPUS_PER_TASK ]
then
    procs=2
else
    procs=$SLURM_CPUS_PER_TASK
fi

# reading input file into niterations array
readarray -t niterations < pi-process-input.txt

# running pi-cpu with parameters
srun ../pi-cpu -p $procs -n ${niterations[${id}]} -r 10