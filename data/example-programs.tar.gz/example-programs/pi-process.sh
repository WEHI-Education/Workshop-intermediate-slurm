#!/bin/bash
# pi-process.sh

#SBATCH --job-name=pi-process
#SBATCH --output=%x-%a.out
#SBATCH --array=0-6
#SBATCH --cpus-per-task=2

if [ -z SLURM_ARRAY_TASK_ID ]
then
    SLURM_ARRAY_TASK_ID=0
fi

if [ -z SLURM_CPUS_PER_TASK ]
then
    SLURM_CPUS_PER_TASK=4
fi

readarray -t niterations < pi-process-input.txt

srun ./pi-cpu -p ${SLURM_CPUS_PER_TASK} -n ${niterations[$SLURM_ARRAY_TASK_ID]} -r 10