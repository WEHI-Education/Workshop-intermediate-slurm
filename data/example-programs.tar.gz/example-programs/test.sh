#!/bin/bash
#SBATCH -c 2 -n 5 --mem 1G

for i in {1..5}
do
	srun -c 2 -n 1 --mem 200 ./pi-cpu &
done
wait
